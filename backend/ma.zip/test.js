const { handler } = require("./index");

const testPayload = {
  body: JSON.stringify({
    name: "John Doe",
    email: "fezekileplaatyi@myplusplus.com",
    subject: "Test Email",
    message: "This is a test email from AWS Lambda.",
  }),
};

const testLambda = async () => {
  try {
    const response = await handler(testPayload);
    console.log("Success:", response);
  } catch (error) {
    console.error("Error:", error);
  }
};

testLambda();
